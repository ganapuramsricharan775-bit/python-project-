"""
Domain Models for Blood Donation Camp Register.
Zero external dependencies - standard library dataclasses.
"""

from dataclasses import dataclass, asdict
from enum import Enum
from typing import Dict, Any, Optional
import datetime


class BloodGroup(str, Enum):
    A_POS = "A+"
    A_NEG = "A-"
    B_POS = "B+"
    B_NEG = "B-"
    AB_POS = "AB+"
    AB_NEG = "AB-"
    O_POS = "O+"
    O_NEG = "O-"

    @classmethod
    def values(cls):
        return [item.value for item in cls]

    @classmethod
    def is_valid(cls, group_str: str) -> bool:
        return group_str.strip().upper() in cls.values()


class DonorStatus(str, Enum):
    ELIGIBLE = "Eligible"
    DEFERRED = "Deferred"
    DONATED = "Donated"

    @classmethod
    def values(cls):
        return [item.value for item in cls]


@dataclass
class DonorRecord:
    donor_id: str
    name: str
    age: int
    gender: str
    blood_group: str
    phone: str
    weight_kg: float
    hemoglobin_g_dl: float
    registration_date: str
    status: str
    deferral_reason: str = ""
    units_donated: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert donor record to a serializable dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DonorRecord":
        """Reconstruct DonorRecord from dictionary with graceful type casting."""
        return cls(
            donor_id=str(data.get("donor_id", "")).strip(),
            name=str(data.get("name", "")).strip(),
            age=int(data.get("age", 0)),
            gender=str(data.get("gender", "Other")).strip().capitalize(),
            blood_group=str(data.get("blood_group", "")).strip().upper(),
            phone=str(data.get("phone", "")).strip(),
            weight_kg=round(float(data.get("weight_kg", 0.0)), 1),
            hemoglobin_g_dl=round(float(data.get("hemoglobin_g_dl", 0.0)), 1),
            registration_date=str(data.get("registration_date", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))),
            status=str(data.get("status", DonorStatus.ELIGIBLE.value)).strip().capitalize(),
            deferral_reason=str(data.get("deferral_reason", "")).strip(),
            units_donated=int(data.get("units_donated", 0))
        )
