"""
Multi-Format Report Exporter for Blood Donation Camp Register.
Generates structured Markdown briefings, standardized CSVs, and audit logs.
"""

import datetime
from pathlib import Path
from typing import List
from .models import DonorRecord, BloodGroup
from .business_logic import CampAnalyticsEngine


class CampReportExporter:
    """Exports analytical and operational summaries in multiple formats."""

    @staticmethod
    def export_to_markdown(records: List[DonorRecord], output_path: str) -> str:
        """Generates a comprehensive executive Markdown briefing."""
        summary = CampAnalyticsEngine.compute_camp_summary(records)
        bg_counts = CampAnalyticsEngine.get_counts_by_blood_group(records)
        warnings = CampAnalyticsEngine.evaluate_threshold_warnings(records)
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        md_lines = [
            "# Blood Donation Camp Executive Register Report",
            "**GreenFuture Hack | Domain: Safety & Community | Project #73**",
            f"*Generated on: {timestamp}*",
            "",
            "---",
            "",
            "## 1. Executive Performance Summary",
            "",
            "| Metric | Value |",
            "|:---|:---|",
            f"| **Total Registrations** | `{summary['total_registrations']}` donors |",
            f"| **Eligible Donors** | `{summary['total_eligible']}` donors |",
            f"| **Completed Donations** | `{summary['total_donated']}` donors |",
            f"| **Medically Deferred** | `{summary['total_deferred']}` donors |",
            f"| **Total Blood Units Collected** | **`{summary['total_units_collected']}` Units** |",
            f"| **Eligibility Rate** | `{summary['eligibility_rate_pct']}%` |",
            f"| **Deferral Rate** | `{summary['deferral_rate_pct']}%` |",
            f"| **Donation Conversion Rate** | `{summary['donation_completion_rate_pct']}%` |",
            "",
            "## 2. Clinical Averages & Donor Demographics",
            "",
            f"- **Mean Age:** `{summary['avg_age']}` years",
            f"- **Mean Weight:** `{summary['avg_weight_kg']}` kg",
            f"- **Mean Hemoglobin:** `{summary['avg_hemoglobin']}` g/dL",
            f"- **Gender Distribution:** {', '.join(f'{k}: {v}' for k, v in summary['gender_breakdown'].items()) or 'N/A'}",
            "",
            "## 3. Blood Group Distribution & Inventory Status",
            "",
            "| Blood Group | Total Registered | Eligible | Donated | Deferred | Units Collected | Inventory Status |",
            "|:---:|:---:|:---:|:---:|:---:|:---:|:---:|",
        ]

        total_reg = summary["total_registrations"]
        for bg in BloodGroup.values():
            d = bg_counts[bg]
            avail = d["eligible"] + d["donated"]
            if bg == "O-" and avail < 2:
                status_tag = "🔴 **CRITICAL SHORTAGE**"
            elif avail == 0:
                status_tag = "⚠️ **ZERO AVAILABLE**"
            elif avail < 2:
                status_tag = "🟡 LOW"
            else:
                status_tag = "🟢 ADEQUATE"

            md_lines.append(
                f"| `{bg}` | {d['total']} | {d['eligible']} | {d['donated']} | {d['deferred']} | {d['units']} | {status_tag} |"
            )

        md_lines.extend([
            "",
            "## 4. Active Threshold Warnings & Clinical Insights",
            ""
        ])

        if not warnings:
            md_lines.append("> 🟢 **All inventory and eligibility metrics are within standard operational limits.**")
        else:
            for w in warnings:
                icon = "🔴" if w["level"] == "CRITICAL" else ("🟡" if w["level"] in ("WARNING", "CAUTION") else "ℹ️")
                md_lines.append(f"> {icon} **[{w['level']}] {w['category']}**: {w['message']}")

        if summary["top_deferral_reasons"]:
            md_lines.extend([
                "",
                "### Primary Deferral Drivers",
                ""
            ])
            for reason, count in summary["top_deferral_reasons"]:
                md_lines.append(f"- **{reason}**: {count} donor(s)")

        md_lines.extend([
            "",
            "---",
            "*Report compiled automatically by Blood Donation Camp Register (Project #73).*"
        ])

        content = "\n".join(md_lines)
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        with open(out, "w", encoding="utf-8") as f:
            f.write(content)

        return str(out.resolve())

    @staticmethod
    def export_to_csv(records: List[DonorRecord], output_path: str) -> str:
        """Exports standardized CSV for spreadsheet analysis."""
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        import csv
        headers = [
            "donor_id", "name", "age", "gender", "blood_group",
            "phone", "weight_kg", "hemoglobin_g_dl",
            "registration_date", "status", "deferral_reason", "units_donated"
        ]
        with open(out, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            for r in records:
                writer.writerow(r.to_dict())
        return str(out.resolve())
