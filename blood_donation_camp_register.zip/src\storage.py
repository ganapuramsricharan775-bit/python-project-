"""
Fault-Tolerant Local Storage Engine for Blood Donation Camp Register.
Handles JSON and CSV persistence, corrupted file recovery, atomic writes, and backups.
"""

import os
import json
import csv
import shutil
import datetime
from pathlib import Path
from typing import List, Tuple, Optional, Dict, Any
from .models import DonorRecord


class StorageManager:
    """Manages persistent storage with automated corruption detection and recovery."""

    def __init__(self, data_dir: Optional[str] = None):
        if data_dir:
            self.data_dir = Path(data_dir)
        else:
            # Default to project root / data directory
            self.data_dir = Path(__file__).resolve().parent.parent / "data"

        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "donors.json"
        self.csv_path = self.data_dir / "donors.csv"
        self.audit_log_path = self.data_dir / "audit_log.txt"

        self._ensure_storage_exists()

    def _ensure_storage_exists(self) -> None:
        """Create empty clean storage files if they do not exist."""
        if not self.json_path.exists():
            self._write_clean_json([])
        if not self.csv_path.exists():
            self._write_clean_csv([])

    def _write_clean_json(self, records: List[Dict[str, Any]]) -> None:
        with open(self.json_path, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2, ensure_ascii=False)

    def _write_clean_csv(self, records: List[DonorRecord]) -> None:
        headers = [
            "donor_id", "name", "age", "gender", "blood_group",
            "phone", "weight_kg", "hemoglobin_g_dl",
            "registration_date", "status", "deferral_reason", "units_donated"
        ]
        with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            for r in records:
                writer.writerow(r.to_dict())

    def load_all_donors(self) -> Tuple[List[DonorRecord], Optional[str]]:
        """
        Loads all donors from JSON storage.
        If file is missing or corrupted (JSONDecodeError), automatically creates
        a timestamped recovery backup and initializes a clean dataset.
        Returns: (records, warning_message_or_None)
        """
        if not self.json_path.exists():
            self._write_clean_json([])
            return [], None

        try:
            with open(self.json_path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    self._write_clean_json([])
                    return [], None
                data = json.loads(content)

            if not isinstance(data, list):
                raise ValueError("JSON root element must be a list of donor records.")

            records: List[DonorRecord] = []
            for item in data:
                if isinstance(item, dict):
                    records.append(DonorRecord.from_dict(item))

            return records, None

        except (json.JSONDecodeError, ValueError) as err:
            # Corrupted storage recovery workflow
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            corrupt_backup = self.data_dir / f"donors_corrupt_{timestamp}.json.bak"
            shutil.copyfile(self.json_path, corrupt_backup)

            # Re-initialize clean file
            self._write_clean_json([])
            warn_msg = (
                f"STORAGE ALERT: Corrupted JSON detected ({type(err).__name__}). "
                f"Archived corrupted file to '{corrupt_backup.name}' and initialized clean register."
            )
            self.log_audit("CORRUPTION_RECOVERY", warn_msg)
            return [], warn_msg

        except Exception as e:
            warn_msg = f"Unexpected error reading storage: {str(e)}"
            self.log_audit("ERROR", warn_msg)
            return [], warn_msg

    def save_all_donors(self, records: List[DonorRecord]) -> bool:
        """
        Saves donor list atomically to JSON and syncs CSV.
        """
        temp_json = self.data_dir / f"donors_temp_{datetime.datetime.now().timestamp()}.tmp"
        try:
            dict_data = [r.to_dict() for r in records]
            with open(temp_json, "w", encoding="utf-8") as f:
                json.dump(dict_data, f, indent=2, ensure_ascii=False)

            # Atomic replace
            os.replace(temp_json, self.json_path)

            # Sync CSV mirror
            self._write_clean_csv(records)
            return True
        except Exception as e:
            if temp_json.exists():
                try:
                    temp_json.unlink()
                except OSError:
                    pass
            self.log_audit("SAVE_ERROR", f"Failed saving records: {str(e)}")
            return False

    def generate_next_donor_id(self, existing_records: List[DonorRecord]) -> str:
        """Generates sequential ID: DON-YYYYMMDD-####"""
        today_str = datetime.datetime.now().strftime("%Y%m%d")
        prefix = f"DON-{today_str}-"
        highest_seq = 0

        for r in existing_records:
            if r.donor_id.startswith(prefix):
                try:
                    seq_part = int(r.donor_id.replace(prefix, ""))
                    if seq_part > highest_seq:
                        highest_seq = seq_part
                except ValueError:
                    pass

        return f"{prefix}{highest_seq + 1:04d}"

    def log_audit(self, action: str, details: str) -> None:
        """Append an event to the local audit trail."""
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] [{action.upper()}] {details}\n"
        try:
            with open(self.audit_log_path, "a", encoding="utf-8") as f:
                f.write(entry)
        except OSError:
            pass
