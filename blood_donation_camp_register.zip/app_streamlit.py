"""
Streamlit Web Interface for Blood Donation Camp Register (Project #73)
Domain: Safety & Community
Built for high-impact college demonstrations and hackathon showcases.
"""

import sys
from pathlib import Path
import datetime
import pandas as pd
import streamlit as st

# Ensure project root is in python path
CURRENT_DIR = Path(__file__).resolve().parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from src.models import DonorRecord, BloodGroup, DonorStatus
from src.validators import (
    validate_name, validate_age, validate_gender, validate_blood_group,
    validate_phone, validate_weight, validate_hemoglobin, evaluate_donor_eligibility
)
from src.storage import StorageManager
from src.business_logic import CampAnalyticsEngine, RecordSearchFilter
from src.exporters import CampReportExporter
from src.importer import BulkCSVImporter


# --- PAGE CONFIGURATION ---
st.set_page_config(
    page_title="Blood Donation Camp Register & Emergency Inventory",
    page_icon="🩸",
    layout="wide",
    initial_sidebar_state="expanded"
)

def show_table(df):
    """Render dataframe safely without deprecation warnings."""
    try:
        st.dataframe(df, width="stretch", hide_index=True)
    except (TypeError, ValueError):
        st.dataframe(df, use_container_width=True, hide_index=True)

# Custom Medical Crimson Styling
st.markdown("""
<style>
    /* Global Accents */
    .stApp {
        background-color: #fafafa;
    }
    .hero-banner {
        background: linear-gradient(135deg, #991b1b 0%, #dc2626 50%, #b91c1c 100%);
        border-radius: 12px;
        padding: 24px 28px;
        color: white;
        margin-bottom: 24px;
        box-shadow: 0 4px 14px rgba(220, 38, 38, 0.25);
    }
    .hero-title {
        font-size: 1.85rem;
        font-weight: 800;
        margin: 0;
        letter-spacing: -0.5px;
    }
    .hero-subtitle {
        font-size: 0.95rem;
        opacity: 0.9;
        margin-top: 4px;
        margin-bottom: 0;
    }
    .blood-badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 700;
        font-size: 0.85rem;
    }
    .blood-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 10px;
        padding: 12px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.03);
        margin-bottom: 10px;
    }
</style>
""", unsafe_allow_html=True)


# --- STATE INITIALIZATION ---
@st.cache_resource
def get_storage_manager():
    return StorageManager(str(CURRENT_DIR / "data"))

storage = get_storage_manager()

def load_data():
    records, warn = storage.load_all_donors()
    if warn and "warn_shown" not in st.session_state:
        st.warning(warn)
        st.session_state["warn_shown"] = True
    return records

donors = load_data()


# --- SIDEBAR NAVIGATION ---
st.sidebar.markdown("""
<div style="text-align: center; padding: 10px 0;">
    <div style="font-size: 3rem;">🩸</div>
    <div style="font-weight: 800; font-size: 1.1rem; color: #dc2626;">REDLIFE REGISTER</div>
    <div style="font-size: 0.75rem; color: #6b7280;">Blood Donation Drive & Analytics</div>
</div>
""", unsafe_allow_html=True)

st.sidebar.markdown("---")
menu_choice = st.sidebar.radio(
    "Navigation Menu:",
    [
        "📊 Live Camp Analytics & KPIs",
        "✍️ Register New Donor",
        "📋 Donor Directory & Search",
        "💉 Phlebotomy & Collect Blood",
        "🧬 Blood Transfusion Matcher",
        "📂 Bulk CSV Dataset Ingestion",
        "📑 Export Reports & Audit Trail"
    ]
)

st.sidebar.markdown("---")
total_units = sum(d.units_donated for d in donors)
st.sidebar.info(
    f"**🏥 Camp Status: ACTIVE**\n\n"
    f"• **Campus Drive:** MRTC Hyderabad\n\n"
    f"• **Registered Donors:** `{len(donors)}`\n\n"
    f"• **Blood Units Collected:** `{total_units}` Bags"
)


# ==============================================================================
# VIEW 1: LIVE ANALYTICS & KPIS
# ==============================================================================
if menu_choice == "📊 Live Camp Analytics & KPIs":
    st.markdown("""
    <div class="hero-banner">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h1 class="hero-title">🩸 Blood Donation Camp Analytics</h1>
                <p class="hero-subtitle">Real-time donor intake, blood inventory meters, and shortage warning engine.</p>
            </div>
            <div style="background: rgba(255,255,255,0.2); padding: 6px 14px; border-radius: 20px; font-weight: 700; font-size: 0.8rem; border: 1px solid rgba(255,255,255,0.3);">
                ● LIVE MONITOR
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    summary = CampAnalyticsEngine.compute_camp_summary(donors)
    bg_counts = CampAnalyticsEngine.get_counts_by_blood_group(donors)
    warnings = CampAnalyticsEngine.evaluate_threshold_warnings(donors)

    # 1. Top KPI Row
    col1, col2, col3, col4, col5 = st.columns(5)
    col1.metric("Total Registered", f"{summary['total_registrations']} Donors", delta="Target: 30+")
    col2.metric("Units Donated", f"{summary['total_units_collected']} Bags", delta=f"{summary['donation_completion_rate_pct']}% converted")
    col3.metric("Eligible Donors", f"{summary['total_eligible']}", delta=f"{summary['eligibility_rate_pct']}% qualified")
    col4.metric("Medically Deferred", f"{summary['total_deferred']}", delta=f"-{summary['deferral_rate_pct']}% deferral", delta_color="inverse")
    col5.metric("Avg Hemoglobin", f"{summary['avg_hemoglobin']} g/dL", help="Clinical Minimum: 12.5 g/dL")

    # 2. Threshold Warning Banners
    if warnings:
        st.markdown("### ⚠️ Active Inventory & Safety Alerts")
        for w in warnings:
            if w["level"] == "CRITICAL":
                st.error(f"🚨 **[{w['level']}] {w['category']}**: {w['message']}")
            elif w["level"] in ("WARNING", "CAUTION"):
                st.warning(f"⚠️ **[{w['level']}] {w['category']}**: {w['message']}")
            else:
                st.info(f"ℹ️ **[{w['level']}] {w['category']}**: {w['message']}")

    st.markdown("---")

    # 3. Blood Group Chart & Table
    st.markdown("### 🩸 Blood Group Inventory Distribution")
    col_chart, col_table = st.columns([1, 1])

    # Prepare DataFrame
    bg_data = []
    for bg in BloodGroup.values():
        d = bg_counts[bg]
        avail = d["eligible"] + d["donated"]
        status_tag = "🔴 Critical Low" if (bg == "O-" and avail < 2) else ("⚠️ Zero" if avail == 0 else ("🟡 Low" if avail < 2 else "🟢 Sufficient"))
        bg_data.append({
            "Blood Group": bg,
            "Total Registered": d["total"],
            "Eligible": d["eligible"],
            "Donated (Units)": d["donated"],
            "Deferred": d["deferred"],
            "Supply Status": status_tag
        })
    df_bg = pd.DataFrame(bg_data)

    with col_chart:
        chart_data = df_bg.set_index("Blood Group")[["Eligible", "Donated (Units)", "Deferred"]]
        st.bar_chart(chart_data)
        st.caption("Figure 1.1: Donor volume breakdown across all 8 blood groups.")

    with col_table:
        show_table(df_bg)

    # 4. Clinical Averages & Deferral Drivers
    col_vitals, col_reasons = st.columns(2)
    with col_vitals:
        st.markdown("### 🏥 Clinical Demographics")
        st.write(f"- **Mean Donor Age:** `{summary['avg_age']}` years")
        st.write(f"- **Mean Body Weight:** `{summary['avg_weight_kg']}` kg (Safety limit: $\ge 50.0$ kg)")
        st.write(f"- **Mean Hemoglobin:** `{summary['avg_hemoglobin']}` g/dL (Safety limit: $\ge 12.5$ g/dL)")
        st.write(f"- **Gender Distribution:** {', '.join(f'{k}: {v}' for k, v in summary['gender_breakdown'].items())}")

    with col_reasons:
        st.markdown("### 📋 Top Medical Deferral Drivers")
        if summary["top_deferral_reasons"]:
            for reason, count in summary["top_deferral_reasons"]:
                st.warning(f"**{reason}** — {count} donor(s)")
        else:
            st.success("No medical deferrals recorded!")


# ==============================================================================
# VIEW 2: REGISTER NEW DONOR
# ==============================================================================
elif menu_choice == "✍️ Register New Donor":
    st.markdown("""
    <div class="hero-banner">
        <h1 class="hero-title">✍️ Donor Registration & Medical Screening</h1>
        <p class="hero-subtitle">Real-time physiological checks, boundary validations, and automated deferral rationale.</p>
    </div>
    """, unsafe_allow_html=True)

    with st.form("register_form", clear_on_submit=False):
        c1, c2 = st.columns(2)
        with c1:
            name_input = st.text_input("Full Name *", placeholder="e.g. Aarav Sharma")
            age_input = st.number_input("Age (Years) * (Must be 18–65)", min_value=1, max_value=100, value=24)
            gender_input = st.selectbox("Gender *", ["Male", "Female", "Other"])
            bg_input = st.selectbox("Blood Group *", BloodGroup.values())

        with c2:
            phone_input = st.text_input("10-Digit Phone Number *", placeholder="9876543210")
            weight_input = st.number_input("Weight (kg) * (Min 50.0 kg for whole blood)", min_value=20.0, max_value=200.0, value=65.0, step=0.5)
            hb_input = st.number_input("Hemoglobin (g/dL) * (Min 12.5 g/dL)", min_value=3.0, max_value=25.0, value=14.0, step=0.1)

        submitted = st.form_submit_button("Verify & Register Donor", type="primary")

    if submitted:
        # Validate inputs defensively
        errors = []
        is_name, name_res = validate_name(name_input)
        if not is_name:
            errors.append(name_res)

        is_phone, phone_res = validate_phone(phone_input)
        if not is_phone:
            errors.append(phone_res)

        if errors:
            for e in errors:
                st.error(f"❌ {e}")
        else:
            # Check clinical eligibility
            status, reason = evaluate_donor_eligibility(int(age_input), float(weight_input), float(hb_input))
            new_id = storage.generate_next_donor_id(donors)

            new_record = DonorRecord(
                donor_id=new_id,
                name=name_res,
                age=int(age_input),
                gender=gender_input,
                blood_group=bg_input,
                phone=phone_res,
                weight_kg=float(weight_input),
                hemoglobin_g_dl=float(hb_input),
                registration_date=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                status=status,
                deferral_reason=reason,
                units_donated=0
            )

            donors.append(new_record)
            if storage.save_all_donors(donors):
                storage.log_audit("WEB_REGISTRATION", f"Registered {new_id} ({name_res}) - Status: {status}")
                st.balloons()
                st.success(f"✅ **Donor successfully registered!** Assigned ID: `{new_id}`")

                if status == DonorStatus.ELIGIBLE.value:
                    st.info(f"🟢 **Clinical Evaluation:** ELIGIBLE to donate whole blood.")
                else:
                    st.error(f"🔴 **Clinical Evaluation:** DEFERRED — {reason}")
            else:
                st.error("Failed to persist record to disk.")


# ==============================================================================
# VIEW 3: DONOR DIRECTORY & SEARCH
# ==============================================================================
elif menu_choice == "📋 Donor Directory & Search":
    st.markdown("""
    <div class="hero-banner">
        <h1 class="hero-title">📋 Volunteer Donors Directory</h1>
        <p class="hero-subtitle">Filter by blood group, age range, clinical status, or keyword search.</p>
    </div>
    """, unsafe_allow_html=True)

    # Filter Controls
    f_col1, f_col2, f_col3, f_col4 = st.columns([1, 1, 1, 2])
    with f_col1:
        f_bg = st.selectbox("Filter Blood Group", ["All"] + BloodGroup.values())
    with f_col2:
        f_status = st.selectbox("Filter Status", ["All", "Eligible", "Donated", "Deferred"])
    with f_col3:
        f_age_min, f_age_max = st.slider("Age Range", 18, 65, (18, 65))
    with f_col4:
        f_search = st.text_input("🔍 Search Keyword (Name, ID, Phone)", placeholder="Search...")

    # Apply Filters
    filtered = RecordSearchFilter.filter_records(
        donors,
        keyword=f_search if f_search else None,
        blood_group=None if f_bg == "All" else f_bg,
        status=None if f_status == "All" else f_status,
        min_age=f_age_min,
        max_age=f_age_max
    )

    st.write(f"Showing **{len(filtered)}** of **{len(donors)}** total records.")

    if filtered:
        df_display = pd.DataFrame([d.to_dict() for d in filtered])
        cols = ["donor_id", "name", "blood_group", "age", "gender", "phone", "weight_kg", "hemoglobin_g_dl", "status", "deferral_reason", "units_donated"]
        df_display = df_display[cols]
        show_table(df_display)

        # Download filtered CSV button
        csv_data = df_display.to_csv(index=False).encode('utf-8')
        st.download_button(
            "📥 Download Filtered Data as CSV",
            data=csv_data,
            file_name="filtered_donors.csv",
            mime="text/csv"
        )
    else:
        st.warning("No donors matched the selected criteria.")


# ==============================================================================
# VIEW 4: PHLEBOTOMY & COLLECT BLOOD
# ==============================================================================
elif menu_choice == "💉 Phlebotomy & Collect Blood":
    st.markdown("""
    <div class="hero-banner">
        <h1 class="hero-title">💉 Phlebotomy Desk & Collection Log</h1>
        <p class="hero-subtitle">Record collection units for clinically eligible candidates in the camp.</p>
    </div>
    """, unsafe_allow_html=True)

    lookup = st.text_input("Enter Donor ID or 10-digit Phone:", placeholder="e.g. DON-20261122-0001 or 9811223344")

    if lookup:
        match = [d for d in donors if d.donor_id.lower() == lookup.strip().lower() or d.phone == lookup.strip()]
        if not match:
            st.error(f"No donor record found for '{lookup}'.")
        else:
            donor = match[0]
            st.info(f"**Found Donor:** `{donor.donor_id}` | **Name:** {donor.name} | **Blood Group:** {donor.blood_group} | **Status:** `{donor.status}`")

            if donor.status == DonorStatus.DEFERRED.value:
                st.error(f"⛔ **DONOR IS MEDICALLY DEFERRED:** {donor.deferral_reason}")
                st.warning("Clinically deferred volunteers cannot donate unless cleared by a doctor.")
            else:
                col_btn1, col_btn2 = st.columns(2)
                with col_btn1:
                    if st.button("🩸 Confirm 1 Unit Collected (Phlebotomy Complete)", type="primary"):
                        donor.status = DonorStatus.DONATED.value
                        donor.units_donated += 1
                        storage.save_all_donors(donors)
                        storage.log_audit("DONATION_LOGGED", f"Logged 1 unit for {donor.donor_id} ({donor.name})")
                        st.success(f"Collection logged! Total units collected from this donor: {donor.units_donated}")
                        st.rerun()

                with col_btn2:
                    defer_reason = st.text_input("Or Defer Donor (Reason):", placeholder="e.g. Elevated blood pressure")
                    if st.button("Mark as Deferred"):
                        donor.status = DonorStatus.DEFERRED.value
                        donor.deferral_reason = defer_reason if defer_reason else "Deferred at phlebotomy desk"
                        storage.save_all_donors(donors)
                        storage.log_audit("DONOR_DEFERRED", f"Deferred {donor.donor_id} - Reason: {donor.deferral_reason}")
                        st.warning("Donor marked as deferred.")
                        st.rerun()


# ==============================================================================
# VIEW 5: BLOOD COMPATIBILITY MATCHER
# ==============================================================================
elif menu_choice == "🧬 Blood Transfusion Matcher":
    st.markdown("""
    <div class="hero-banner">
        <h1 class="hero-title">🧬 Blood Transfusion Compatibility Matrix</h1>
        <p class="hero-subtitle">Interactive clinical tool mapping compatible donors and recipients for whole blood.</p>
    </div>
    """, unsafe_allow_html=True)

    compat_data = {
        "O-": {
            "give": ["O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+"],
            "receive": ["O-"],
            "desc": "🌟 Universal Red Cell Donor: Can be transfused to any patient in emergency trauma situations when time does not permit cross-matching."
        },
        "O+": {
            "give": ["O+", "A+", "B+", "AB+"],
            "receive": ["O-", "O+"],
            "desc": "Most prevalent blood group. Crucial for positive recipients."
        },
        "A-": {
            "give": ["A-", "A+", "AB-", "AB+"],
            "receive": ["A-", "O-"],
            "desc": "Rare negative blood type. Critical for specialized surgeries."
        },
        "A+": {
            "give": ["A+", "AB+"],
            "receive": ["A+", "A-", "O+", "O-"],
            "desc": "Common blood group with broad utility."
        },
        "B-": {
            "give": ["B-", "B+", "AB-", "AB+"],
            "receive": ["B-", "O-"],
            "desc": "Scarce blood type. High demand in regional pediatric oncology."
        },
        "B+": {
            "give": ["B+", "AB+"],
            "receive": ["B+", "B-", "O+", "O-"],
            "desc": "High prevalence in South Asian populations."
        },
        "AB-": {
            "give": ["AB-", "AB+"],
            "receive": ["AB-", "A-", "B-", "O-"],
            "desc": "The rarest blood type on Earth (< 1% of the population)."
        },
        "AB+": {
            "give": ["AB+"],
            "receive": ["AB+", "AB-", "A+", "A-", "B+", "B-", "O+", "O-"],
            "desc": "🌟 Universal Red Cell Recipient: Can safely receive red blood cells from any blood type."
        }
    }

    selected_bg = st.selectbox("Select Blood Group to Inspect Compatibility:", list(compat_data.keys()), index=0)

    info = compat_data[selected_bg]
    st.info(f"**Clinical Insight:** {info['desc']}")

    col_give, col_rec = st.columns(2)
    with col_give:
        st.markdown(f"#### 🩸 **{selected_bg}** Can DONATE Red Cells To:")
        give_pills = " ".join([f"`{g}`" for g in info["give"]])
        st.markdown(f"### {give_pills}")

    with col_rec:
        st.markdown(f"#### 📥 **{selected_bg}** Can RECEIVE Red Cells From:")
        rec_pills = " ".join([f"`{g}`" for g in info["receive"]])
        st.markdown(f"### {rec_pills}")


# ==============================================================================
# VIEW 6: BULK CSV INGESTION
# ==============================================================================
elif menu_choice == "📂 Bulk CSV Dataset Ingestion":
    st.markdown("""
    <div class="hero-banner">
        <h1 class="hero-title">📂 Bulk CSV Dataset Ingestion</h1>
        <p class="hero-subtitle">Ingest legacy datasets with line-by-line validation and automated error logging.</p>
    </div>
    """, unsafe_allow_html=True)

    uploaded_file = st.file_uploader("Upload CSV File", type=["csv"])
    seed_btn = st.button("Test with Pre-Bundled Hackathon Seed CSV (sample_donors_seed.csv)")

    target_path = None
    if seed_btn:
        target_path = str(CURRENT_DIR / "data" / "sample_donors_seed.csv")
    elif uploaded_file:
        temp_path = CURRENT_DIR / "exports" / f"uploaded_{uploaded_file.name}"
        temp_path.parent.mkdir(exist_ok=True)
        with open(temp_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        target_path = str(temp_path)

    if target_path:
        st.write(f"Processing File: `{Path(target_path).name}`")
        new_records, failures, error_log_path, messages = BulkCSVImporter.import_from_csv(
            target_path, donors, logs_dir=(CURRENT_DIR / "exports")
        )

        for m in messages:
            st.write(f"- {m}")

        if new_records:
            existing_ids = {d.donor_id for d in donors}
            to_add = [r for r in new_records if r.donor_id not in existing_ids]
            donors.extend(to_add)
            storage.save_all_donors(donors)
            st.success(f"✅ Successfully ingested {len(to_add)} valid donor records into the camp register!")

        if failures > 0 and error_log_path and Path(error_log_path).exists():
            st.error(f"⚠️ {failures} rows rejected due to validation errors.")
            with open(error_log_path, "r", encoding="utf-8") as lf:
                log_content = lf.read()
            st.text_area("Detailed Row-by-Row Rejection Log:", log_content, height=180)


# ==============================================================================
# VIEW 7: EXPORT REPORTS & AUDIT TRAIL
# ==============================================================================
elif menu_choice == "📑 Export Reports & Audit Trail":
    st.markdown("""
    <div class="hero-banner">
        <h1 class="hero-title">📑 Executive Reports & Audit Trail</h1>
        <p class="hero-subtitle">Generate structured Markdown summaries, standardized CSV exports, and security audit logs.</p>
    </div>
    """, unsafe_allow_html=True)

    export_dir = CURRENT_DIR / "exports"
    export_dir.mkdir(exist_ok=True)
    md_file = export_dir / "camp_executive_report.md"
    csv_file = export_dir / "donors_standardized_export.csv"

    md_path = CampReportExporter.export_to_markdown(donors, str(md_file))
    csv_path = CampReportExporter.export_to_csv(donors, str(csv_file))

    with open(md_path, "r", encoding="utf-8") as f:
        md_text = f.read()

    col1, col2 = st.columns(2)
    with col1:
        st.download_button(
            "📥 Download Executive Markdown Brief",
            data=md_text,
            file_name="camp_executive_report.md",
            mime="text/markdown"
        )
    with col2:
        with open(csv_path, "rb") as f:
            csv_bytes = f.read()
        st.download_button(
            "📥 Download Standardized CSV Dataset",
            data=csv_bytes,
            file_name="donors_export.csv",
            mime="text/csv"
        )

    st.markdown("### 📄 Markdown Report Preview")
    st.markdown(md_text)

    # Audit Trail Viewer
    st.markdown("---")
    st.markdown("### 🔒 Chronological Audit Trail")
    if storage.audit_log_path.exists():
        with open(storage.audit_log_path, "r", encoding="utf-8") as f:
            audit_lines = f.readlines()[-30:]
        st.code("".join(audit_lines), language="text")
