"""
Application Entrypoint & Dispatch Loop for Blood Donation Camp Register.
GreenFuture Hack: Project #73 | Domain: Safety & Community
Zero-dependency Python 3.10+ execution.
"""

import sys
import os
from pathlib import Path
from typing import List, Optional

# Add parent directory to sys.path so modules run cleanly from any working directory
CURRENT_DIR = Path(__file__).resolve().parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from src.models import DonorRecord, BloodGroup, DonorStatus
from src.validators import (
    validate_name, validate_age, validate_gender, validate_blood_group,
    validate_phone, validate_weight, validate_hemoglobin, evaluate_donor_eligibility,
    prompt_text, prompt_numeric
)
from src.storage import StorageManager
from src.business_logic import CampAnalyticsEngine, RecordSearchFilter
from src.importer import BulkCSVImporter
from src.exporters import CampReportExporter
from src.ui import (
    Colors, print_banner, print_menu, paginate_records,
    display_analytics_dashboard, display_warnings_panel, format_status_badge
)


class BloodDonationApp:
    def __init__(self):
        self.storage = StorageManager(str(CURRENT_DIR / "data"))
        self.donors: List[DonorRecord] = []
        self._load_data()

    def _load_data(self):
        records, warn_msg = self.storage.load_all_donors()
        self.donors = records
        if warn_msg:
            print(f"\n{Colors.YELLOW}[!] {warn_msg}{Colors.RESET}")

    def run(self):
        """Primary interactive application loop."""
        print_banner()
        print(f"System initialized. Loaded {len(self.donors)} existing donor records.\n")

        while True:
            try:
                print_menu()
                choice = input(f"{Colors.BOLD}Select an option (0-9): {Colors.RESET}").strip()

                if choice == "1":
                    self.action_register_donor()
                elif choice == "2":
                    self.action_view_all_donors()
                elif choice == "3":
                    self.action_search_filter()
                elif choice == "4":
                    self.action_update_donor_status()
                elif choice == "5":
                    self.action_view_analytics()
                elif choice == "6":
                    self.action_check_warnings()
                elif choice == "7":
                    self.action_export_reports()
                elif choice == "8":
                    self.action_bulk_import()
                elif choice == "9":
                    self.action_system_diagnostics()
                elif choice == "0":
                    print(f"\n{Colors.GREEN}Thank you for supporting community health & safety. Exiting.{Colors.RESET}\n")
                    sys.exit(0)
                else:
                    print(f"\n{Colors.RED}[X] Invalid option '{choice}'. Please enter a number between 0 and 9.{Colors.RESET}")

            except (KeyboardInterrupt, EOFError):
                print(f"\n\n{Colors.YELLOW}[!] Program interrupted by user. Exiting safely...{Colors.RESET}\n")
                sys.exit(0)

    # ---------------- MENU ACTIONS ----------------

    def action_register_donor(self):
        """Guided registration flow with real-time defensive validation."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- REGISTER NEW BLOOD DONOR ---{Colors.RESET}")
        print(f"{Colors.DIM}(Tip: Enter 'c' at any prompt to cancel registration){Colors.RESET}\n")

        # 1. Full Name
        name = prompt_text("Enter Full Name:", validate_name)
        if not name:
            print(f"{Colors.YELLOW}[-] Registration cancelled.{Colors.RESET}")
            return

        # 2. Age
        age = prompt_numeric("Enter Age (18-65):", validate_age)
        if age is None:
            print(f"{Colors.YELLOW}[-] Registration cancelled.{Colors.RESET}")
            return

        # 3. Gender
        gender = prompt_text("Enter Gender (Male/Female/Other):", validate_gender)
        if not gender:
            print(f"{Colors.YELLOW}[-] Registration cancelled.{Colors.RESET}")
            return

        # 4. Blood Group
        print(f"Supported Groups: {', '.join(BloodGroup.values())}")
        blood_group = prompt_text("Enter Blood Group (e.g. O+, A-, B+):", validate_blood_group)
        if not blood_group:
            print(f"{Colors.YELLOW}[-] Registration cancelled.{Colors.RESET}")
            return

        # 5. Phone Number
        phone = prompt_text("Enter 10-digit Phone Number:", validate_phone)
        if not phone:
            print(f"{Colors.YELLOW}[-] Registration cancelled.{Colors.RESET}")
            return

        # Check for potential duplicate phone registration in current camp
        existing_match = [d for d in self.donors if d.phone == phone]
        if existing_match:
            print(f"{Colors.YELLOW}[!] Notice: Phone number already registered under ID: {existing_match[0].donor_id} ({existing_match[0].name}){Colors.RESET}")
            proceed = input("Continue anyway? (y/N): ").strip().lower()
            if proceed != 'y':
                print(f"{Colors.YELLOW}[-] Registration aborted.{Colors.RESET}")
                return

        # 6. Weight
        weight = prompt_numeric("Enter Weight in kg (Min 50kg for donation):", validate_weight)
        if weight is None:
            print(f"{Colors.YELLOW}[-] Registration cancelled.{Colors.RESET}")
            return

        # 7. Hemoglobin
        hb = prompt_numeric("Enter Hemoglobin in g/dL (Min 12.5 g/dL for donation):", validate_hemoglobin)
        if hb is None:
            print(f"{Colors.YELLOW}[-] Registration cancelled.{Colors.RESET}")
            return

        # Evaluate clinical eligibility
        status, deferral_reason = evaluate_donor_eligibility(age, weight, hb)
        donor_id = self.storage.generate_next_donor_id(self.donors)

        new_record = DonorRecord(
            donor_id=donor_id,
            name=name,
            age=age,
            gender=gender,
            blood_group=blood_group,
            phone=phone,
            weight_kg=weight,
            hemoglobin_g_dl=hb,
            registration_date=import_datetime(),
            status=status,
            deferral_reason=deferral_reason,
            units_donated=0
        )

        # Show confirmation preview
        print(f"\n{Colors.BOLD}┌─ DONOR REGISTRATION SUMMARY ─────────────────────────────────┐{Colors.RESET}")
        print(f"│ ID:          {new_record.donor_id:<46} │")
        print(f"│ Name:        {new_record.name:<46} │")
        print(f"│ Blood Group: {new_record.blood_group:<46} │")
        print(f"│ Age / Sex:   {f'{new_record.age} yrs / {new_record.gender}':<46} │")
        print(f"│ Vitals:      {f'Weight: {new_record.weight_kg}kg | Hb: {new_record.hemoglobin_g_dl}g/dL':<46} │")
        print(f"│ Status:      {new_record.status:<46} │")
        if deferral_reason:
            print(f"│ Reason:      {Colors.RED}{deferral_reason[:46]:<46}{Colors.RESET} │")
        print(f"{Colors.BOLD}└──────────────────────────────────────────────────────────────┘{Colors.RESET}")

        confirm = input("\nSave this donor registration? (Y/n): ").strip().lower()
        if confirm in ('', 'y', 'yes'):
            self.donors.append(new_record)
            if self.storage.save_all_donors(self.donors):
                self.storage.log_audit("REGISTRATION", f"Registered {new_record.donor_id} ({new_record.name}) - Status: {new_record.status}")
                print(f"\n{Colors.GREEN}[✓] Donor successfully registered! ID: {new_record.donor_id}{Colors.RESET}")
                if status == DonorStatus.DEFERRED.value:
                    print(f"{Colors.RED}[!] Donor is Medically Deferred: {deferral_reason}{Colors.RESET}")
                else:
                    print(f"{Colors.GREEN}[✓] Donor is Clinically Eligible for blood collection.{Colors.RESET}")
            else:
                print(f"{Colors.RED}[X] Failed to write donor record to disk storage.{Colors.RESET}")
        else:
            print(f"{Colors.YELLOW}[-] Registration discarded.{Colors.RESET}")

    def action_view_all_donors(self):
        """Displays all donors in a paginated, formatted table."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- ALL REGISTERED DONORS ({len(self.donors)}) ---{Colors.RESET}")
        paginate_records(self.donors, page_size=10)

    def action_search_filter(self):
        """Filter donors by Blood Group, Status, or keyword."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- SEARCH & FILTER DONORS ---{Colors.RESET}")
        print("1. Filter by Blood Group")
        print("2. Filter by Eligibility Status (Eligible / Deferred / Donated)")
        print("3. Search by Keyword (Name, ID, Phone, Deferral Reason)")
        print("4. Filter by Age Range")
        print("0. Back to Main Menu")

        sub_choice = input("\nSelect filter type (0-4): ").strip()
        if sub_choice == "1":
            print(f"Groups: {', '.join(BloodGroup.values())}")
            bg = input("Enter Blood Group: ").strip().upper()
            filtered = RecordSearchFilter.filter_records(self.donors, blood_group=bg)
            print(f"\nFound {len(filtered)} donor(s) with Blood Group '{bg}':")
            paginate_records(filtered)
        elif sub_choice == "2":
            print(f"Status options: Eligible, Deferred, Donated")
            st = input("Enter Status: ").strip().capitalize()
            filtered = RecordSearchFilter.filter_records(self.donors, status=st)
            print(f"\nFound {len(filtered)} donor(s) with Status '{st}':")
            paginate_records(filtered)
        elif sub_choice == "3":
            kw = input("Enter search keyword: ").strip()
            filtered = RecordSearchFilter.filter_records(self.donors, keyword=kw)
            print(f"\nFound {len(filtered)} donor(s) matching '{kw}':")
            paginate_records(filtered)
        elif sub_choice == "4":
            try:
                min_a = int(input("Enter minimum age: ").strip())
                max_a = int(input("Enter maximum age: ").strip())
                filtered = RecordSearchFilter.filter_records(self.donors, min_age=min_a, max_age=max_a)
                print(f"\nFound {len(filtered)} donor(s) aged between {min_a} and {max_a}:")
                paginate_records(filtered)
            except ValueError:
                print(f"{Colors.RED}[X] Invalid numeric age entered.{Colors.RESET}")

    def action_update_donor_status(self):
        """Log blood collection or update deferral."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- UPDATE DONOR / LOG PHLEBOTOMY COLLECTION ---{Colors.RESET}")
        query = input("Enter Donor ID or Phone Number: ").strip()
        if not query:
            return

        matches = [d for d in self.donors if d.donor_id.lower() == query.lower() or d.phone == query]
        if not matches:
            print(f"{Colors.RED}[X] No donor found matching '{query}'.{Colors.RESET}")
            return

        donor = matches[0]
        print(f"\nFound Donor: {donor.donor_id} | {donor.name} | {donor.blood_group} | Status: {format_status_badge(donor.status)}")
        print(f"Current Units Donated: {donor.units_donated}")

        if donor.status == DonorStatus.DEFERRED.value:
            print(f"{Colors.RED}[!] WARNING: Donor was marked DEFERRED: {donor.deferral_reason}{Colors.RESET}")
            override = input("Do you wish to clinically override and mark as Eligible? (y/N): ").strip().lower()
            if override == 'y':
                donor.status = DonorStatus.ELIGIBLE.value
                donor.deferral_reason = ""
                print(f"{Colors.GREEN}[✓] Donor status updated to Eligible.{Colors.RESET}")
            else:
                return

        print("\nOptions:")
        print("1. Mark Blood Collection Completed (Logs 1 Unit Donated)")
        print("2. Mark as Medically Deferred")
        print("0. Cancel")

        opt = input("Choose action (0-2): ").strip()
        if opt == "1":
            donor.status = DonorStatus.DONATED.value
            donor.units_donated += 1
            self.storage.save_all_donors(self.donors)
            self.storage.log_audit("DONATION_COMPLETED", f"Collected 1 unit from {donor.donor_id} ({donor.name}, {donor.blood_group})")
            print(f"\n{Colors.GREEN}[✓] Phlebotomy recorded! Donor marked as Donated. Total Units: {donor.units_donated}{Colors.RESET}")
        elif opt == "2":
            reason = input("Enter reason for medical deferral: ").strip()
            if not reason:
                reason = "Deferred by attending phlebotomist"
            donor.status = DonorStatus.DEFERRED.value
            donor.deferral_reason = reason
            self.storage.save_all_donors(self.donors)
            self.storage.log_audit("DONOR_DEFERRED", f"Deferred {donor.donor_id} - Reason: {reason}")
            print(f"\n{Colors.YELLOW}[✓] Donor marked as Deferred.{Colors.RESET}")

    def action_view_analytics(self):
        """Displays executive camp performance dashboard and blood group distribution."""
        summary = CampAnalyticsEngine.compute_camp_summary(self.donors)
        bg_counts = CampAnalyticsEngine.get_counts_by_blood_group(self.donors)
        display_analytics_dashboard(summary, bg_counts)

    def action_check_warnings(self):
        """Evaluates inventory thresholds and flags shortages."""
        warnings = CampAnalyticsEngine.evaluate_threshold_warnings(self.donors)
        display_warnings_panel(warnings)

    def action_export_reports(self):
        """Exports summaries to Markdown, CSV, and displays audit trail."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- MULTI-FORMAT REPORT EXPORT ---{Colors.RESET}")
        export_dir = CURRENT_DIR / "exports"
        export_dir.mkdir(exist_ok=True)

        md_file = export_dir / "camp_executive_report.md"
        csv_file = export_dir / "donors_standardized_export.csv"

        md_path = CampReportExporter.export_to_markdown(self.donors, str(md_file))
        csv_path = CampReportExporter.export_to_csv(self.donors, str(csv_file))

        print(f"\n{Colors.GREEN}[✓] Reports generated successfully!{Colors.RESET}")
        print(f"  * Markdown Executive Brief: {md_path}")
        print(f"  * Standardized CSV Dataset: {csv_path}")
        print(f"  * Local Audit Trail File:   {self.storage.audit_log_path.resolve()}")
        self.storage.log_audit("REPORT_EXPORT", f"Exported Markdown and CSV reports to {export_dir.name}")

    def action_bulk_import(self):
        """Ingests legacy CSV dataset with row-by-row error logging."""
        print(f"\n{Colors.CYAN}{Colors.BOLD}--- BULK CSV DATASET INGESTION ---{Colors.RESET}")
        default_seed = CURRENT_DIR / "data" / "sample_donors_seed.csv"
        print(f"Default seed path: {default_seed}")
        csv_input = input(f"Enter CSV file path (or press Enter for default seed): ").strip()

        target_file = csv_input if csv_input else str(default_seed)
        new_records, failures, log_path, messages = BulkCSVImporter.import_from_csv(
            target_file, self.donors, logs_dir=(CURRENT_DIR / "exports")
        )

        for m in messages:
            print(f"  {m}")

        if new_records:
            # Append non-duplicate records
            existing_ids = {d.donor_id for d in self.donors}
            to_add = [r for r in new_records if r.donor_id not in existing_ids]

            self.donors.extend(to_add)
            self.storage.save_all_donors(self.donors)
            self.storage.log_audit("BULK_IMPORT", f"Ingested {len(to_add)} records from {Path(target_file).name} (Failures: {failures})")
            print(f"\n{Colors.GREEN}[✓] Successfully merged {len(to_add)} new records into register! Total donors: {len(self.donors)}{Colors.RESET}")
        else:
            print(f"\n{Colors.YELLOW}[!] No valid new records were added.{Colors.RESET}")

    def action_system_diagnostics(self):
        """Displays storage diagnostics, file health, and system checks."""
        print(f"\n{Colors.BLUE}{Colors.BOLD}--- SYSTEM & STORAGE HEALTH DIAGNOSTICS ---{Colors.RESET}")
        json_size = self.storage.json_path.stat().st_size if self.storage.json_path.exists() else 0
        csv_size = self.storage.csv_path.stat().st_size if self.storage.csv_path.exists() else 0
        audit_size = self.storage.audit_log_path.stat().st_size if self.storage.audit_log_path.exists() else 0

        print(f"  * JSON Primary Store:    {self.storage.json_path.resolve()} ({json_size} bytes)")
        print(f"  * CSV Mirror Store:      {self.storage.csv_path.resolve()} ({csv_size} bytes)")
        print(f"  * Audit Trail Log:       {self.storage.audit_log_path.resolve()} ({audit_size} bytes)")
        print(f"  * Memory In-Sync Donors: {len(self.donors)} records")
        print(f"  * Fault-Tolerance:       Active (Corrupted JSON auto-backup + Atomic writes)")
        print(f"{Colors.GREEN}[✓] All storage subsystems healthy and verified.{Colors.RESET}")


def import_datetime() -> str:
    import datetime
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def main():
    app = BloodDonationApp()
    app.run()


if __name__ == "__main__":
    main()
