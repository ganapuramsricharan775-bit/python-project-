"""
Defensive Input Validation Engine for Blood Donation Camp Register.
Ensures zero crashes from malformed, blank, or out-of-boundary inputs.
"""

import re
from typing import Tuple, List, Optional, Callable, Any
from .models import BloodGroup, DonorStatus


# Standard Clinical Donation Thresholds
MIN_DONATION_AGE = 18
MAX_DONATION_AGE = 65
MIN_DONATION_WEIGHT_KG = 50.0
MIN_DONATION_HB_G_DL = 12.5

# Physiological boundaries (to detect impossible values / data entry errors)
PHYSIO_MIN_AGE = 1
PHYSIO_MAX_AGE = 120
PHYSIO_MIN_WEIGHT_KG = 20.0
PHYSIO_MAX_WEIGHT_KG = 300.0
PHYSIO_MIN_HB = 3.0
PHYSIO_MAX_HB = 25.0


def validate_name(name: str) -> Tuple[bool, str]:
    cleaned = name.strip()
    if not cleaned:
        return False, "Donor name cannot be blank."
    if len(cleaned) < 2:
        return False, "Donor name must be at least 2 characters."
    if len(cleaned) > 50:
        return False, "Donor name cannot exceed 50 characters."
    # Allow alphabetic characters, spaces, hyphens, and apostrophes
    if not re.match(r"^[A-Za-z\s'\-]+$", cleaned):
        return False, "Donor name must contain only letters, spaces, hyphens, or apostrophes."
    return True, cleaned.title()


def validate_age(age_val: Any) -> Tuple[bool, str, int]:
    try:
        age = int(age_val)
    except (ValueError, TypeError):
        return False, "Age must be a valid whole integer.", 0

    if age < PHYSIO_MIN_AGE or age > PHYSIO_MAX_AGE:
        return False, f"Age must be physiologically realistic ({PHYSIO_MIN_AGE}-{PHYSIO_MAX_AGE} years).", 0

    return True, "", age


def validate_gender(gender_val: str) -> Tuple[bool, str]:
    cleaned = gender_val.strip().capitalize()
    valid_genders = ["Male", "Female", "Other", "M", "F", "O"]
    if cleaned not in valid_genders:
        return False, "Gender must be Male (M), Female (F), or Other (O)."
    mapping = {"M": "Male", "F": "Female", "O": "Other"}
    return True, mapping.get(cleaned, cleaned)


def validate_blood_group(bg_str: str) -> Tuple[bool, str]:
    cleaned = bg_str.strip().upper()
    valid_groups = BloodGroup.values()
    if cleaned not in valid_groups:
        return False, f"Invalid blood group '{bg_str}'. Must be one of: {', '.join(valid_groups)}"
    return True, cleaned


def validate_phone(phone_str: str) -> Tuple[bool, str]:
    cleaned = re.sub(r"[\s\-\(\)]", "", phone_str.strip())
    # Handle optional +91 or leading 0
    if cleaned.startswith("+91") and len(cleaned) == 13:
        cleaned = cleaned[3:]
    elif cleaned.startswith("0") and len(cleaned) == 11:
        cleaned = cleaned[1:]

    if not cleaned.isdigit() or len(cleaned) != 10:
        return False, "Phone number must be a valid 10-digit number (e.g., 9876543210)."
    return True, cleaned


def validate_weight(weight_val: Any) -> Tuple[bool, str, float]:
    try:
        weight = round(float(weight_val), 1)
    except (ValueError, TypeError):
        return False, "Weight must be a valid number.", 0.0

    if weight < PHYSIO_MIN_WEIGHT_KG or weight > PHYSIO_MAX_WEIGHT_KG:
        return False, f"Weight must be between {PHYSIO_MIN_WEIGHT_KG}kg and {PHYSIO_MAX_WEIGHT_KG}kg.", 0.0

    return True, "", weight


def validate_hemoglobin(hb_val: Any) -> Tuple[bool, str, float]:
    try:
        hb = round(float(hb_val), 1)
    except (ValueError, TypeError):
        return False, "Hemoglobin must be a valid numeric measurement.", 0.0

    if hb < PHYSIO_MIN_HB or hb > PHYSIO_MAX_HB:
        return False, f"Hemoglobin must be between {PHYSIO_MIN_HB} and {PHYSIO_MAX_HB} g/dL.", 0.0

    return True, "", hb


def evaluate_donor_eligibility(age: int, weight_kg: float, hemoglobin_g_dl: float) -> Tuple[str, str]:
    """
    Evaluates clinical eligibility for blood donation.
    Returns (status, reason):
        status: 'Eligible' or 'Deferred'
        reason: empty string if eligible, or medical rationale for deferral.
    """
    reasons = []

    if age < MIN_DONATION_AGE:
        reasons.append(f"Underage: {age} yrs (minimum {MIN_DONATION_AGE} yrs required)")
    elif age > MAX_DONATION_AGE:
        reasons.append(f"Overage: {age} yrs (maximum {MAX_DONATION_AGE} yrs allowed)")

    if weight_kg < MIN_DONATION_WEIGHT_KG:
        reasons.append(f"Underweight: {weight_kg} kg (minimum {MIN_DONATION_WEIGHT_KG} kg required)")

    if hemoglobin_g_dl < MIN_DONATION_HB_G_DL:
        reasons.append(f"Low Hemoglobin: {hemoglobin_g_dl} g/dL (minimum {MIN_DONATION_HB_G_DL} g/dL required)")

    if reasons:
        return DonorStatus.DEFERRED.value, "; ".join(reasons)
    return DonorStatus.ELIGIBLE.value, ""


# Interactive CLI Prompt Helpers with Safe Input Loops

def prompt_text(prompt_msg: str, validator: Optional[Callable[[str], Tuple[bool, str]]] = None, allow_cancel: bool = True) -> Optional[str]:
    """Loop until user provides a valid string conforming to validator."""
    while True:
        try:
            val = input(f"{prompt_msg} ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n[!] Input aborted.")
            return None

        if allow_cancel and val.lower() in ('c', 'cancel', 'abort', 'quit'):
            return None

        if not validator:
            if val:
                return val
            print("  [!] Input cannot be empty. (Enter 'c' to cancel)")
            continue

        is_valid, result = validator(val)
        if is_valid:
            return result
        print(f"  [X] {result} (Enter 'c' to cancel)")


def prompt_numeric(prompt_msg: str, validator: Callable[[Any], Tuple[bool, str, Any]], allow_cancel: bool = True) -> Optional[Any]:
    """Loop until user provides valid numeric input conforming to validator."""
    while True:
        try:
            val = input(f"{prompt_msg} ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n[!] Input aborted.")
            return None

        if allow_cancel and val.lower() in ('c', 'cancel', 'abort', 'quit'):
            return None

        is_valid, err_msg, parsed_val = validator(val)
        if is_valid:
            return parsed_val
        print(f"  [X] {err_msg} (Enter 'c' to cancel)")
