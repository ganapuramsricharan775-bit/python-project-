"""
Terminal Presentation Layer (UI / TUI) for Blood Donation Camp Register.
Provides ANSI styling, ASCII box borders, pagination, and colored status badges.
Zero external dependencies.
"""

import os
import sys
from typing import List, Dict, Any, Optional
from .models import DonorRecord, BloodGroup, DonorStatus


# Terminal Color Support
class Colors:
    HEADER = "\033[95m"
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RESET = "\033[0m"

    @classmethod
    def strip_if_unsupported(cls):
        # Disable ANSI if Windows terminal without virtual terminal processing
        if os.name == "nt" and not os.environ.get("WT_SESSION"):
            try:
                import ctypes
                kernel32 = ctypes.windll.kernel32
                kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
            except Exception:
                pass


Colors.strip_if_unsupported()


def print_banner():
    """Prints branded hackathon header."""
    banner = f"""
{Colors.CYAN}{Colors.BOLD}╔══════════════════════════════════════════════════════════════════════════════╗
║                    GREENFUTURE HACK: PROJECT #73                             ║
║             BLOOD DONATION CAMP REGISTER & ANALYTICS ENGINE                  ║
║                  Domain: Safety & Community | v1.0.0                         ║
╚══════════════════════════════════════════════════════════════════════════════╝{Colors.RESET}
"""
    print(banner)


def print_menu():
    """Displays the main command menu with clear visual categories."""
    menu = f"""
{Colors.BOLD}┌─ MAIN NAVIGATION ────────────────────────────────────────────────────────────┐{Colors.RESET}
│  {Colors.GREEN}[1]{Colors.RESET} Register New Donor (Live Medical Validation)                              │
│  {Colors.GREEN}[2]{Colors.RESET} View All Registered Donors (Paginated Table)                              │
│  {Colors.GREEN}[3]{Colors.RESET} Search & Filter Donors (Blood Group, Status, Keyword)                    │
│  {Colors.GREEN}[4]{Colors.RESET} Update Donor Status (Log Blood Collection / Phlebotomy)                  │
│  {Colors.CYAN}[5]{Colors.RESET} View Camp Analytics & Blood Group Breakdown                               │
│  {Colors.YELLOW}[6]{Colors.RESET} Evaluate Inventory Shortages & Safety Warnings                            │
│  {Colors.CYAN}[7]{Colors.RESET} Multi-Format Report Export (Markdown Brief, CSV, Audit Trail)             │
│  {Colors.CYAN}[8]{Colors.RESET} Bulk CSV Dataset Ingestion (with Row-by-Row Error Logs)                   │
│  {Colors.BLUE}[9]{Colors.RESET} Storage Diagnostics & Recovery Health Check                               │
│  {Colors.RED}[0]{Colors.RESET} Exit Application                                                          │
{Colors.BOLD}└──────────────────────────────────────────────────────────────────────────────┘{Colors.RESET}
"""
    print(menu)


def format_status_badge(status: str) -> str:
    """Returns color-coded status badge."""
    if status == DonorStatus.ELIGIBLE.value:
        return f"{Colors.GREEN}[Eligible]{Colors.RESET}"
    elif status == DonorStatus.DONATED.value:
        return f"{Colors.BLUE}[Donated]{Colors.RESET}"
    elif status == DonorStatus.DEFERRED.value:
        return f"{Colors.RED}[Deferred]{Colors.RESET}"
    return f"[{status}]"


def display_donor_table_page(records: List[DonorRecord], page_num: int, total_pages: int):
    """Renders a single page of donor records in a fixed-width table."""
    border = "+------------------+----------------------+-----+-----+--------+------------+--------+--------+------------+"
    header = "| ID               | Name                 | Age | Sex | Blood  | Phone      | Wt(kg) | Hb(gL) | Status     |"

    print(f"\n{Colors.BOLD}Showing Page {page_num} of {total_pages} (Total Records: {len(records)}){Colors.RESET}")
    print(border)
    print(header)
    print(border)

    for r in records:
        # truncate name if too long for table layout
        short_name = (r.name[:19] + "..") if len(r.name) > 20 else r.name
        status_disp = r.status[:10]
        color_start = ""
        if r.status == DonorStatus.ELIGIBLE.value:
            color_start = Colors.GREEN
        elif r.status == DonorStatus.DONATED.value:
            color_start = Colors.BLUE
        elif r.status == DonorStatus.DEFERRED.value:
            color_start = Colors.RED

        row = (
            f"| {r.donor_id:<16} | {short_name:<20} | {r.age:>3} | {r.gender[:1]:<3} | "
            f"{r.blood_group:<6} | {r.phone:<10} | {r.weight_kg:>6.1f} | {r.hemoglobin_g_dl:>6.1f} | "
            f"{color_start}{status_disp:<10}{Colors.RESET} |"
        )
        print(row)

    print(border)


def paginate_records(records: List[DonorRecord], page_size: int = 10):
    """Interactive table pagination loop to handle arbitrary volume without overwhelming terminal."""
    if not records:
        print(f"\n{Colors.YELLOW}[!] No matching donor records found.{Colors.RESET}")
        return

    total_records = len(records)
    total_pages = (total_records + page_size - 1) // page_size
    current_page = 1

    while True:
        start_idx = (current_page - 1) * page_size
        end_idx = min(start_idx + page_size, total_records)
        page_slice = records[start_idx:end_idx]

        display_donor_table_page(page_slice, current_page, total_pages)

        if total_pages <= 1:
            break

        print(f"\nNavigation: [N]ext Page | [P]revious Page | [1-{total_pages}] Jump | [Q]uit Table View")
        choice = input("Select navigation option (or Enter to quit): ").strip().lower()

        if choice in ('q', '', 'exit'):
            break
        elif choice == 'n':
            if current_page < total_pages:
                current_page += 1
            else:
                print(f"{Colors.YELLOW}Already at the last page.{Colors.RESET}")
        elif choice == 'p':
            if current_page > 1:
                current_page -= 1
            else:
                print(f"{Colors.YELLOW}Already at the first page.{Colors.RESET}")
        elif choice.isdigit():
            target = int(choice)
            if 1 <= target <= total_pages:
                current_page = target
            else:
                print(f"{Colors.RED}Invalid page number.{Colors.RESET}")


def display_analytics_dashboard(summary: Dict[str, Any], bg_counts: Dict[str, Dict[str, int]]):
    """Prints a styled terminal analytics dashboard."""
    print(f"\n{Colors.CYAN}{Colors.BOLD}====================== CAMP ANALYTICS DASHBOARD ======================{Colors.RESET}")

    # Top KPI summary cards
    print(f"{Colors.BOLD}+----------------------------+----------------------------+{Colors.RESET}")
    print(f"| Total Registered: {summary['total_registrations']:<8} | Total Units Donated: {summary['total_units_collected']:<6} |")
    print(f"| Eligible Donors:  {summary['total_eligible']:<8} | Completed Donors:    {summary['total_donated']:<6} |")
    print(f"| Deferred Donors:  {summary['total_deferred']:<8} | Eligibility Rate:    {summary['eligibility_rate_pct']:<5}% |")
    print(f"| Avg Donor Age:    {summary['avg_age']:<5} yrs | Avg Hemoglobin:      {summary['avg_hemoglobin']:<4} g/dL |")
    print(f"{Colors.BOLD}+----------------------------+----------------------------+{Colors.RESET}")

    # Blood group count table
    print(f"\n{Colors.BOLD}--- BLOOD GROUP INVENTORY & STATUS BREAKDOWN ---{Colors.RESET}")
    print("+-------------+-------+----------+---------+----------+-------+--------------------+")
    print("| Blood Group | Total | Eligible | Donated | Deferred | Units | Supply Status      |")
    print("+-------------+-------+----------+---------+----------+-------+--------------------+")

    for bg in BloodGroup.values():
        d = bg_counts[bg]
        avail = d["eligible"] + d["donated"]
        if bg == "O-" and avail < 2:
            status_tag = f"{Colors.RED}CRITICAL LOW{Colors.RESET}   "
        elif avail == 0:
            status_tag = f"{Colors.YELLOW}ZERO SUPPLY{Colors.RESET}    "
        elif avail < 2:
            status_tag = f"{Colors.YELLOW}LOW SUPPLY{Colors.RESET}     "
        else:
            status_tag = f"{Colors.GREEN}SUFFICIENT{Colors.RESET}     "

        print(
            f"| {bg:<11} | {d['total']:>5} | {d['eligible']:>8} | {d['donated']:>7} | "
            f"{d['deferred']:>8} | {d['units']:>5} | {status_tag} |"
        )

    print("+-------------+-------+----------+---------+----------+-------+--------------------+")

    # Deferral drivers
    if summary["top_deferral_reasons"]:
        print(f"\n{Colors.YELLOW}Primary Deferral Reasons:{Colors.RESET}")
        for r_name, r_count in summary["top_deferral_reasons"]:
            print(f"  * {r_name} -> {r_count} donor(s)")


def display_warnings_panel(warnings: List[Dict[str, str]]):
    """Displays safety threshold indicators and alert banners."""
    print(f"\n{Colors.BOLD}--- INVENTORY SHORTAGE & THRESHOLD WARNINGS ---{Colors.RESET}")
    if not warnings:
        print(f"{Colors.GREEN}[OK] All inventory targets and safety metrics are within safe operational parameters.{Colors.RESET}")
        return

    for w in warnings:
        level = w["level"]
        if level == "CRITICAL":
            badge = f"{Colors.RED}[CRITICAL ALERT]{Colors.RESET}"
        elif level in ("WARNING", "CAUTION"):
            badge = f"{Colors.YELLOW}[WARNING]{Colors.RESET}"
        else:
            badge = f"{Colors.BLUE}[NOTICE]{Colors.RESET}"

        print(f"{badge} {Colors.BOLD}{w['category']}:{Colors.RESET} {w['message']}")
