"""
Core Computational & Analytics Engine for Blood Donation Camp Register.
Generates counts by blood group, computes summary metrics, checks shortage warnings,
and provides query/filtering logic.
"""

from typing import List, Dict, Any, Optional
from collections import Counter
from .models import DonorRecord, BloodGroup, DonorStatus


# Safety / Operational Inventory Thresholds
CRITICAL_O_NEG_MINIMUM = 2
MINIMUM_GROUP_SAFETY_TARGET = 2
HIGH_DEFERRAL_PERCENT_THRESHOLD = 25.0


class CampAnalyticsEngine:
    """Computes all domain metrics, statistics, and alert states."""

    @staticmethod
    def get_counts_by_blood_group(records: List[DonorRecord]) -> Dict[str, Dict[str, int]]:
        """
        Calculates comprehensive counts for every blood group:
        Returns:
            {
               'O+': {'total': 12, 'eligible': 8, 'donated': 3, 'deferred': 1, 'units': 3},
               ...
            }
        """
        all_groups = BloodGroup.values()
        stats: Dict[str, Dict[str, int]] = {
            bg: {"total": 0, "eligible": 0, "donated": 0, "deferred": 0, "units": 0}
            for bg in all_groups
        }

        for r in records:
            bg = r.blood_group.upper()
            if bg not in stats:
                stats[bg] = {"total": 0, "eligible": 0, "donated": 0, "deferred": 0, "units": 0}

            stats[bg]["total"] += 1
            if r.status == DonorStatus.ELIGIBLE.value:
                stats[bg]["eligible"] += 1
            elif r.status == DonorStatus.DONATED.value:
                stats[bg]["donated"] += 1
            elif r.status == DonorStatus.DEFERRED.value:
                stats[bg]["deferred"] += 1

            stats[bg]["units"] += r.units_donated

        return stats

    @staticmethod
    def compute_camp_summary(records: List[DonorRecord]) -> Dict[str, Any]:
        """
        Aggregates executive camp metrics: totals, rates, and clinical averages.
        """
        total = len(records)
        if total == 0:
            return {
                "total_registrations": 0,
                "total_eligible": 0,
                "total_donated": 0,
                "total_deferred": 0,
                "total_units_collected": 0,
                "eligibility_rate_pct": 0.0,
                "deferral_rate_pct": 0.0,
                "donation_completion_rate_pct": 0.0,
                "avg_age": 0.0,
                "avg_weight_kg": 0.0,
                "avg_hemoglobin": 0.0,
                "gender_breakdown": {},
                "top_deferral_reasons": []
            }

        status_counts = Counter(r.status for r in records)
        eligible_count = status_counts[DonorStatus.ELIGIBLE.value]
        donated_count = status_counts[DonorStatus.DONATED.value]
        deferred_count = status_counts[DonorStatus.DEFERRED.value]
        total_units = sum(r.units_donated for r in records)

        # Rates
        eligibility_rate = ((eligible_count + donated_count) / total) * 100
        deferral_rate = (deferred_count / total) * 100
        conversion_rate = (donated_count / (eligible_count + donated_count) * 100) if (eligible_count + donated_count) > 0 else 0.0

        # Clinical averages
        avg_age = sum(r.age for r in records) / total
        avg_weight = sum(r.weight_kg for r in records) / total
        avg_hb = sum(r.hemoglobin_g_dl for r in records) / total

        # Gender
        gender_counts = dict(Counter(r.gender for r in records))

        # Deferral reasons analysis
        deferral_reasons = [r.deferral_reason for r in records if r.deferral_reason]
        reason_counter = Counter(deferral_reasons)
        top_reasons = reason_counter.most_common(3)

        return {
            "total_registrations": total,
            "total_eligible": eligible_count,
            "total_donated": donated_count,
            "total_deferred": deferred_count,
            "total_units_collected": total_units,
            "eligibility_rate_pct": round(eligibility_rate, 1),
            "deferral_rate_pct": round(deferral_rate, 1),
            "donation_completion_rate_pct": round(conversion_rate, 1),
            "avg_age": round(avg_age, 1),
            "avg_weight_kg": round(avg_weight, 1),
            "avg_hemoglobin": round(avg_hb, 1),
            "gender_breakdown": gender_counts,
            "top_deferral_reasons": top_reasons
        }

    @staticmethod
    def evaluate_threshold_warnings(records: List[DonorRecord]) -> List[Dict[str, str]]:
        """
        Generates automated alert and threshold warnings:
        - Universal donor shortage (O-)
        - Rare negative groups (AB-, B-, A-) with zero or deficit counts
        - Abnormally high deferral rates
        - Zero unit collected warnings
        """
        warnings = []
        if not records:
            warnings.append({
                "level": "INFO",
                "category": "Zero Records",
                "message": "Camp register is currently empty. Seed or register donors to generate live trends."
            })
            return warnings

        bg_counts = CampAnalyticsEngine.get_counts_by_blood_group(records)
        summary = CampAnalyticsEngine.compute_camp_summary(records)

        # 1. Universal Donor (O-) check
        o_neg_available = bg_counts["O-"]["eligible"] + bg_counts["O-"]["donated"]
        if o_neg_available < CRITICAL_O_NEG_MINIMUM:
            warnings.append({
                "level": "CRITICAL",
                "category": "Universal Donor Shortage",
                "message": f"Critical shortage of Universal Donor (O-): Only {o_neg_available} available donor(s) (Safety threshold: {CRITICAL_O_NEG_MINIMUM})."
            })

        # 2. Rare blood group deficiencies
        rare_groups = ["AB-", "B-", "A-"]
        for group in rare_groups:
            avail = bg_counts[group]["eligible"] + bg_counts[group]["donated"]
            if avail == 0:
                warnings.append({
                    "level": "WARNING",
                    "category": "Rare Group Deficit",
                    "message": f"Zero available donor registrations for rare blood type '{group}'."
                })
            elif avail < MINIMUM_GROUP_SAFETY_TARGET:
                warnings.append({
                    "level": "CAUTION",
                    "category": "Low Group Inventory",
                    "message": f"Low supply for blood group '{group}': {avail} donor(s) registered."
                })

        # 3. High Deferral Rate Warning
        if summary["deferral_rate_pct"] >= HIGH_DEFERRAL_PERCENT_THRESHOLD:
            warnings.append({
                "level": "WARNING",
                "category": "Elevated Medical Deferral Rate",
                "message": f"Deferral rate is {summary['deferral_rate_pct']}% (exceeds {HIGH_DEFERRAL_PERCENT_THRESHOLD}% threshold). Inspect health screening standards."
            })

        # 4. Low camp conversion
        if summary["total_eligible"] > 5 and summary["total_donated"] == 0:
            warnings.append({
                "level": "NOTICE",
                "category": "Pending Phlebotomy",
                "message": f"{summary['total_eligible']} eligible donors registered, but 0 blood collection units logged so far."
            })

        return warnings


class RecordSearchFilter:
    """Flexible query and search utility for donor records."""

    @staticmethod
    def filter_records(
        records: List[DonorRecord],
        keyword: Optional[str] = None,
        blood_group: Optional[str] = None,
        status: Optional[str] = None,
        min_age: Optional[int] = None,
        max_age: Optional[int] = None,
    ) -> List[DonorRecord]:
        """Filters donor records against multiple combined criteria."""
        results = records

        if blood_group and blood_group.strip():
            target_bg = blood_group.strip().upper()
            results = [r for r in results if r.blood_group == target_bg]

        if status and status.strip():
            target_status = status.strip().capitalize()
            results = [r for r in results if r.status == target_status]

        if min_age is not None:
            results = [r for r in results if r.age >= min_age]

        if max_age is not None:
            results = [r for r in results if r.age <= max_age]

        if keyword and keyword.strip():
            kw = keyword.strip().lower()
            results = [
                r for r in results
                if (kw in r.name.lower() or
                    kw in r.donor_id.lower() or
                    kw in r.phone.lower() or
                    kw in r.deferral_reason.lower())
            ]

        return results
